
public class Entry {
	public static void main(String[] args) throws EmployeeNotFoundException {
		
		Employee employee[]=new Employee[5];
		
		JoiningMonth jme1=new JoiningMonth("01","08","2016");
		employee[0]=new Employee("Anand","Singh",jme1,60000,"AVP");	
	
		JoiningMonth jme2=new JoiningMonth("01","01","2015");
		employee[1]=new Employee("Peter","Bragmen",jme2,40000,"BA1");
		
		JoiningMonth jme3=new JoiningMonth("01","12","2013");
		employee[2]=new Employee("Ruby","Rangwin",jme3,50000,"BA2");
		
		JoiningMonth jme4=new JoiningMonth("01","08","2014");
		employee[3]=new Employee("Stud","Rawat",jme4,60000,"BA4");
		
		JoiningMonth jme5=new JoiningMonth("01","08","2011");
		employee[4]=new Employee("Sacks","Irony",jme5,90000,"VP");
		try{
		findEmployee(10,employee);
		}
		catch(EmployeeNotFoundException enfe){
			enfe.printStackTrace();
		}
		finally{
			System.out.println("This statement must be printed ");
		}
}
	public static void findEmployee(int id,Employee[] employee) throws EmployeeNotFoundException{
		if(id-1>=employee.length||id-1<0)
			throw new EmployeeNotFoundException();
		employee[id-1].showDetails();
		
	}
}
