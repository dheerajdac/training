
public interface Daao {

}
