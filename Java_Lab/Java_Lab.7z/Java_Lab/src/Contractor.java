
public class Contractor {
	private String name;
	public  class CBEmployee{
		private String name;
		public CBEmployee(){
			this.name="Kumar";
			System.out.println(Contractor.this.name);
		}
	}
}
